"""Untimed diagnosis of functional weight consumers; never changes frozen inputs."""

import argparse
import contextlib
import copy
import json
import os
from functools import partial
from pathlib import Path

import bench_packed_gpu as bench
import six_gpu_reference as reference
import torch

from neuralzip.gpu import inference
from neuralzip.setup import NeuralZipSetup


def decode_functional(block, _parent, inputs):
    bench.decode_dfloat(block, inputs)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("method", choices=("dfloat11", "own", "transfer"))
    parser.add_argument("--fix-hooks", action="store_true")
    parser.add_argument("--both", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(8)
    torch.set_num_interop_threads(1)
    os.sched_setaffinity(0, set(range(16)))
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    data = Path("/benchmark/transfer-full-rerun-20261005-0244/cpu-inputs")
    spec = next(s for s in json.loads((data / "six_model_suite.json").read_text()) if s["key"] == "siglip2")
    named = torch.load("/benchmark/inputs/siglip2.pt", weights_only=True, map_location="cpu")
    model, ignored = reference.load_model(spec, named, os.environ["HF_HUB_CACHE"])
    _, candidates = inference._gpu_candidates(model)
    candidates = inference._unique_candidates(model, candidates)
    expected = {c.tensor_name: c.parameter.detach().clone() for c in candidates}
    functional = {}
    for c in candidates:
        parent_name, _, child = c.module_name.rpartition(".")
        parent = model.get_submodule(parent_name)
        if child == "out_proj" and isinstance(parent, torch.nn.MultiheadAttention):
            functional[c.block_name] = parent_name
    print(json.dumps({"method": args.method, "functional_consumers": functional, "fix_hooks": args.fix_hooks}), flush=True)
    if args.method == "dfloat11":
        with open(os.devnull, "w") as quiet, contextlib.redirect_stdout(quiet):
            calls, fallback = bench.attach_dfloat(model, candidates)
        model.cuda()
        for call in calls:
            call()
        if args.fix_hooks:
            for name, target in functional.items():
                block = model.get_submodule(name)
                block._forward_pre_hooks.clear()
                model.get_submodule(target).register_forward_pre_hook(partial(decode_functional, block))
    else:
        label = "new" if args.method == "own" else "foreign"
        setup = copy.deepcopy(NeuralZipSetup.load(data / "six" / f"siglip2-{label}.setup.pkl"))
        exported = inference.export_model_for_gpu(model, setup)
        runtime = inference.NeuralZipRuntime.attach(model, exported, device="cuda:0")
        print(json.dumps({"payload_sha256": bench.export_identity(exported)}), flush=True)
        if args.fix_hooks:
            for name, target in functional.items():
                block = model.get_submodule(name)
                block._forward_pre_hooks.clear()
                model.get_submodule(target).register_forward_pre_hook(partial(runtime._decode_block, name))
    failures = []
    seen = set()

    def check_weight(candidate, _module, _inputs):
        actual = model.get_submodule(candidate.module_name).weight
        seen.add(candidate.tensor_name)
        if not reference.exact(actual, expected[candidate.tensor_name]):
            failures.append(candidate.tensor_name)
            print(json.dumps({"incorrect_weight_at_use": candidate.tensor_name}), flush=True)

    for c in candidates:
        target = functional.get(c.block_name, c.module_name)
        model.get_submodule(target).register_forward_pre_hook(partial(check_weight, c))
    inputs = reference.inputs_for("siglip2", model)
    actual = reference.outputs_for(model(**inputs))
    saved = Path("/benchmark/packed-decode-pr18-20261005/results/candidate-staging/1/siglip2-reference.pt")
    original = torch.load(saved, weights_only=True, map_location="cpu")
    def report(phase, output):
        print(json.dumps({
            "phase": phase,
            "weights_checked": len(seen),
            "incorrect_weights": sorted(set(failures)),
            "output_keys_match": output.keys() == original.keys(),
            "outputs": {n: {"bitwise": reference.exact(t, original[n]), "max_abs_error": (t.float()-original[n].float()).abs().max().item()} for n, t in output.items()},
        }), flush=True)

    report("fixed" if args.fix_hooks else "original", actual)
    if args.both:
        assert not args.fix_hooks
        for name, target in functional.items():
            block = model.get_submodule(name)
            block._forward_pre_hooks.clear()
            hook = partial(decode_functional, block) if args.method == "dfloat11" else partial(runtime._decode_block, name)
            model.get_submodule(target).register_forward_pre_hook(hook, prepend=True)
        failures.clear()
        seen.clear()
        report("fixed", reference.outputs_for(model(**inputs)))


if __name__ == "__main__":
    with torch.inference_mode():
        main()
