"""Qwen-only ABBA controls using the unchanged, validated GPU benchmark."""

import fcntl
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from statistics import median

PARENT = Path('/home/martin/neuralzip-runs/packed-decode-pr18-20261005')
ROOT = PARENT / 'qwen-paired-20261006-0015'
ABLATIONS = PARENT / 'ablations-20261005-2326'
SCRIPTS = ABLATIONS / 'scripts'
SOURCE = PARENT / 'candidate-staging-functional'
DATA = Path('/home/martin/neuralzip-runs/transfer-full-rerun-20261005-0244')
INPUTS = Path('/dev/shm/martin-nzip-six-20261002')
DFLOAT = Path('/home/martin/neuralzip-runs/chunk-rerun-20261002/dfloat-source')
DEPS = Path('/home/martin/neuralzip-runs/chunk-rerun-20261002/dependencies')
CACHE = Path('/dev/shm/martin-nzip-specialized-six-20261002/cache')
HARNESS_SHA = '4e2ac0f114a71ddb0cb95a8f77e9713f68db24b859c073a1e8fb064b438370f8'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate():
    records = {}
    for pair in ('1', '2'):
        records[pair] = {}
        for method, variant in [('bf16', 'control'), ('packing', 'candidate')]:
            path = ROOT / 'results' / pair / '1' / f'qwen35-{variant}-{method}.json'
            row = json.loads(path.read_text())
            assert row['runner_sha256'] == HARNESS_SHA
            assert len(row['inference_trials_ms']) == 5
            assert all(v > 0 for v in row['inference_trials_ms'])
            assert median(row['inference_trials_ms']) == row['inference_ms']
            assert all(row[k] is True for k in ('weight_bitwise', 'output_bitwise', 'input_unchanged', 'setup_frozen', 'full_decode_each_forward'))
            assert row['profiling_in_timing'] is False
            assert row['protocol'] == dict(physical_gpu=0, threads=8, affinity=list(range(16)), batch=1, attention='eager', cache=False, offload=False, warmups=20, trials=5, forwards_per_trial=50)
            records[pair][method] = row
    control = records['1']['bf16']
    fields = ('pinned_model', 'manifest_sha256', 'input_file_sha256', 'selected_weight_sha256', 'forward_input_sha256', 'protocol', 'gpu_uuid', 'torch_version', 'cuda_version', 'cupy_version', 'official_sha256', 'functional_consumer_adapter', 'source_hashes')
    for pair in records.values():
        for row in pair.values():
            for field in fields:
                assert row[field] == control[field], field
        assert pair['packing']['allocated_gpu_bytes'] < pair['bf16']['allocated_gpu_bytes']
        assert pair['packing']['peak_gpu_bytes'] < pair['bf16']['peak_gpu_bytes']
    reference = ROOT / 'results' / '1' / '1' / 'qwen35-control-bf16.json'
    for pair in records.values():
        assert pair['packing']['bf16_reference_record_sha256'] == digest(reference)
    first = records['1']['packing']
    second = records['2']['packing']
    for field in ('setup_sha256', 'ablation_cpu_record_sha256', 'payload_sha256', 'compressed_names', 'packed_chunks', 'groups', 'runtime_metadata_bytes', 'allocated_gpu_bytes', 'peak_gpu_bytes'):
        assert first[field] == second[field], field
    assert first['packed_chunks'] > 0
    assert digest(ROOT / 'results' / '1' / '1' / 'qwen35-reference.pt') == digest(ROOT / 'results' / '2' / '1' / 'qwen35-reference.pt')
    return {'passed': True, 'sequence': ['bf16', 'packing', 'packing', 'bf16'], 'comparisons': [{
        'pair': pair,
        'bf16_ms': rows['bf16']['inference_ms'],
        'packing_ms': rows['packing']['inference_ms'],
        'packing_over_bf16': rows['packing']['inference_ms'] / rows['bf16']['inference_ms'],
        'bf16_trials_ms': rows['bf16']['inference_trials_ms'],
        'packing_trials_ms': rows['packing']['inference_trials_ms'],
        'bf16_live_bytes': rows['bf16']['allocated_gpu_bytes'],
        'packing_live_bytes': rows['packing']['allocated_gpu_bytes'],
        'bf16_peak_bytes': rows['bf16']['peak_gpu_bytes'],
        'packing_peak_bytes': rows['packing']['peak_gpu_bytes'],
    } for pair, rows in records.items()]}


def main():
    if '--check-only' in sys.argv:
        print(json.dumps(validate(), indent=2), flush=True)
        return
    ROOT.mkdir(parents=True, exist_ok=True)
    assert not (ROOT / 'results').exists(), 'Never overwrite measurements'
    lock = (ROOT / 'launcher.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert digest(SCRIPTS / 'bench_packed_gpu.py') == HARNESS_SHA
    sys.path.insert(0, str(SCRIPTS))
    from run_packed_gpu_campaign import wait_for_gpu
    env = os.environ.copy()
    env.update(CUDA_VISIBLE_DEVICES='0', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_CACHE=str(CACHE), OMP_NUM_THREADS='8', MKL_NUM_THREADS='8', PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=os.pathsep.join(map(str, (SOURCE, DATA, DFLOAT, DEPS))))
    for pair, method in [('1', 'bf16'), ('1', 'packing'), ('2', 'packing'), ('2', 'bf16')]:
        wait_for_gpu(0)
        output = ROOT / 'results' / pair
        args = [sys.executable, str(SCRIPTS / 'bench_packed_gpu.py'), 'qwen35', method, '--variant', 'control' if method == 'bf16' else 'candidate', '--campaign', '1', '--gpu', '0', '--data-root', str(DATA), '--inputs', str(INPUTS), '--output', str(output)]
        if method == 'packing':
            args += ['--ablation-root', str(ABLATIONS / 'frozen-cpu'), '--reference-root', str(ROOT / 'results' / '1')]
        print(json.dumps({'pair': pair, 'method': method, 'stage': 'started'}), flush=True)
        subprocess.run(args, cwd=SOURCE, env=env, check=True)
        print(json.dumps({'pair': pair, 'method': method, 'stage': 'finished'}), flush=True)
    report = validate()
    with (ROOT / 'validation.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
