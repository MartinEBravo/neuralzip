"""Fetch only two pinned config.json files using Godel's existing HF client.

Run in its established tmux environment. Never inspect, print, export or save
credentials; no weights or setup files are requested and no timing is run.
"""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/data/mbravo/table3-refresh-20261006')
BASE = Path('/data/mbravo/table3-final-20261002')
KEYS = ('llama32-3b', 'gemma3-4b')


def pinned_spec(spec):
    assert spec['kind'] == 'hf' and not spec.get('subfolder')
    revision = spec['revision']
    assert len(revision) == 40 and all(c in '0123456789abcdef' for c in revision)
    return spec['id'], revision


def main():
    from huggingface_hub import hf_hub_download
    specs = json.loads((BASE / 'manifest.json').read_text())['models']
    result = {}
    for key in KEYS:
        repository, revision = pinned_spec(specs[key])
        path = Path(hf_hub_download(repository, 'config.json', revision=revision,
                                   cache_dir=ROOT / 'hf-configs-v3'))
        data = path.read_bytes()
        assert 0 < len(data) < (1 << 20) and isinstance(json.loads(data), dict)
        result[key] = dict(repository=repository, revision=revision, path=str(path),
                           bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                           existing_client_authentication_only=True,
                           credentials_inspected_or_saved=False,
                           weights_downloaded=False, preparation_only=True)
    destination = ROOT / 'gated-configs-v3.json'
    if destination.exists():
        assert json.loads(destination.read_text()) == result
    else:
        with destination.open('x') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    if '--self-test' in sys.argv:
        assert pinned_spec(dict(kind='hf', id='example/model', revision='a' * 40)) == ('example/model', 'a' * 40)
        try:
            pinned_spec(dict(kind='hf', id='example/model', revision='main'))
        except AssertionError:
            pass
        else:
            raise AssertionError('Unpinned metadata accepted')
        print('Pinned JSON-only preparation self-check passed')
    else:
        main()
