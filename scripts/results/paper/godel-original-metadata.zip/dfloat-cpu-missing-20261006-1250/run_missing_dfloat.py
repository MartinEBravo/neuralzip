"""Measure only five explicitly requested empty DFloat11 CPU rows on Godel."""
import argparse
import fcntl
import gc
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

BASE = Path('/data/mbravo/table3-final-20261002')
ROOT = Path('/data/mbravo/dfloat-cpu-missing-20261006-1250')
INPUTS = Path('/dev/shm/mbravo-table3-refresh-20261006/inputs')
OFFICIAL = Path('/data/mbravo/DFloat11-checkpoint-baseline-20260930')
MODELS = ('deepseek-r1-distill-llama-8b', 'qwen25-7b-distilled', 'phi4-14b',
          'deepseek-moe-16b', 'qwen3-30b-a3b')
COMMIT = '457733886ce6ebc6d8dda1621fad1ffa2661e028'
UTILS_SHA = 'c50216fda9da2a516131ce84afec6003f566f6e0f88cb4fa8178bc18f83851fe'
PRIMITIVE_SHA = 'e5dc1f8fd18831944313fb5f351f666710b759090875d33a1062f2a583e1edd0'


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def runtime():
    assert sorted(os.sched_getaffinity(0)) == list(range(12))
    assert os.environ['DFLOAT_SOURCE'] == str(OFFICIAL)
    assert sha(OFFICIAL / 'dfloat11/dfloat11_utils.py') == UTILS_SHA
    assert sha(BASE / 'scripts/run_chunk_dfloat.py') == PRIMITIVE_SHA
    assert subprocess.check_output(['git', '-C', str(OFFICIAL), 'rev-parse', 'HEAD'], text=True).strip() == COMMIT
    source = read(BASE / 'source-manifest.json')
    assert len(source['cpu_files']) == 14
    for name, digest in source['cpu_files'].items():
        assert sha(BASE / 'software/cpu' / name) == digest
    info = {}
    for key in MODELS:
        original = BASE / 'table3' / f'{key}-input.json'
        assert not (BASE / 'table3' / f'{key}-dfloat11.json').exists(), 'Do not repeat a completed method'
        assert (INPUTS / f'{key}.pt').is_file() and not (INPUTS / f'{key}.pt').is_symlink()
        info[key] = dict(original_input_sha256=sha(original), input=read(original),
                         original_tensor_manifest_sha256=sha(BASE / 'table3' / f'{key}-tensors.json'),
                         serialized_input_bytes=(INPUTS / f'{key}.pt').stat().st_size)
    return dict(models=list(MODELS), CPU_only=True, threads=12, affinity=list(range(12)),
                official_commit=COMMIT, official_utils_sha256=UTILS_SHA, primitive_sha256=PRIMITIVE_SHA,
                immutable_CPU_files=source['cpu_files'], driver_sha256=sha(Path(__file__)),
                input_identities=info, no_download=True, no_GPU=True, no_existing_results_overwritten=True,
                protocol='One official tensorwise CPU encode per model, including exponent statistics, Huffman, LUT and restart construction. Original raw singleton/unsupported-LUT fallback. Bitwise decode, loading and input verification outside timing.')


def measure(key):
    import torch
    from load_chunk_inputs import tensor_manifest
    from run_chunk_dfloat import dfloat_pass
    torch.set_num_threads(12)
    torch.set_num_interop_threads(1)
    protocol = runtime()
    target = ROOT / f'{key}-dfloat11.json'
    assert key in MODELS and not target.exists()
    identity = protocol['input_identities'][key]['input']
    input_path = INPUTS / f'{key}.pt'
    before_file = sha(input_path)
    named = tuple(sorted(torch.load(input_path, weights_only=True).items()))
    original = tensor_manifest(named)
    assert original == read(BASE / 'table3' / f'{key}-tensors.json')
    assert hashlib.sha256(json.dumps(original, sort_keys=True).encode()).hexdigest() == identity['bf16_manifest_sha256']
    assert len(named) == identity['tensors'] and sum(t.numel() * 2 for _, t in named) == identity['raw_bytes']
    assert all(t.dtype == torch.bfloat16 for _, t in named)
    save(ROOT / f'{key}-input.json', identity)
    save(ROOT / f'{key}-tensors.json', original)
    save(ROOT / f'{key}-before.json', dict(input_archive_sha256=before_file,
         monotonic_seconds=time.monotonic(), process_pid=os.getpid(),
         process_memory=Path('/proc/self/status').read_text(), original_BF16_verified=True))
    print(json.dumps(dict(measuring=key, tensors=len(named), raw_bytes=identity['raw_bytes'])), flush=True)
    result = dfloat_pass(named)  # The existing official timing primitive is byte-unchanged.
    assert tensor_manifest(named) == original and sha(input_path) == before_file
    assert result['exponent_raw_bytes'] * 2 == identity['raw_bytes']
    result.update(model=key, method='dfloat11', input=identity, input_unchanged=True,
                  threads=12, affinity=sorted(os.sched_getaffinity(0)), measurements=1,
                  full_compressed_bytes=result['exponent_raw_bytes'] + result['exponent_compressed_bytes'],
                  official_commit=COMMIT, official_utils_sha256=UTILS_SHA,
                  primitive_runner_sha256=PRIMITIVE_SHA, runner_sha256=sha(Path(__file__)),
                  input_archive_sha256=before_file, protocol=protocol['protocol'],
                  after_process_memory=Path('/proc/self/status').read_text())
    save(target, result)
    del named
    gc.collect()
    print(json.dumps(dict(complete=key, encode_seconds=result['encode_seconds'],
                          exponent_ratio_pct=result['exponent_ratio_pct'])), flush=True)


def controller():
    ROOT.mkdir(exist_ok=True)
    locks = []
    for path in (ROOT / 'timing.lock', BASE / 'timing.lock',
                 Path('/data/mbravo/table3-refresh-20261006/timing.lock'),
                 Path('/data/mbravo/shared-table1-ablations-20261005/timing.lock'),
                 Path('/data/mbravo/strict-levels-20261005/timing.lock'),
                 Path('/data/mbravo/cpu-consistency-six-20261006-1100/controller.lock')):
        handle = path.open('a' if path.parent == ROOT else 'r')
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        locks.append(handle)
    protocol = runtime()
    assert not (ROOT / 'protocol.json').exists(), 'No duplicate launch or silent resume'
    preserved = {str(p): sha(p) for folder in ('table3', 'controls', 'donors', 'sources')
                 for p in sorted((BASE / folder).glob('*.json'))}
    protocol['original_json_sha256'] = preserved
    save(ROOT / 'protocol.json', protocol)
    complete = []
    errors = []
    for key in MODELS:
        save(ROOT / 'progress.json', dict(finished=False, model=key, completed=complete, errors=errors))
        with (ROOT / f'{key}.log').open('x') as log:
            child = subprocess.Popen([sys.executable, '-u', __file__, '--model', key],
                                     stdout=log, stderr=subprocess.STDOUT)
            save(ROOT / 'active-process.json', dict(controller_pid=os.getpid(), child_pid=child.pid, model=key))
            code = child.wait()
        if code:
            errors.append(dict(model=key, returncode=code, log=f'{key}.log'))
            save(ROOT / 'progress.json', dict(finished=True, completed=complete, errors=errors))
            return code
        result = read(ROOT / f'{key}-dfloat11.json')
        assert result['roundtrip_exact'] and result['input_unchanged']
        assert all(sha(Path(path)) == digest for path, digest in preserved.items())
        complete.append(key)
        save(ROOT / f'{key}-COMPLETE.json', dict(complete=True, result_sha256=sha(ROOT / f'{key}-dfloat11.json'),
             original_metadata_preserved=True))
    save(ROOT / 'progress.json', dict(finished=True, completed=complete, errors=[]))
    save(ROOT / 'COMPLETE.json', dict(complete=True, models=complete, original_metadata_preserved=True))
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', choices=MODELS)
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        assert len(MODELS) == len(set(MODELS)) == 5
        assert 100 + 40 == (200 // 2) + 40  # BF16 untouched stream plus stored exponents.
        assert all(len(value) == 64 for value in (UTILS_SHA, PRIMITIVE_SHA))
        print('Five-model scope, byte accounting and source-pin guards passed')
    elif args.preflight:
        print(json.dumps(runtime(), indent=2))
    elif args.model:
        measure(args.model)
    else:
        sys.exit(controller())
