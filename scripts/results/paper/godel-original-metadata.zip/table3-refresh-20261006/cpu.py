"""Refresh only the retained Table 3 transfers, using the current Table 1 bank."""
import copy
import fcntl
import gc
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

KEYS = tuple('resnet101 olmo2-7b convnext-base efficientnet-b3 gpt2 bert-base '
             'qwen25-7b qwen35-2b-base llama32-3b gemma3-4b sd15-unet '
             'deepseek-r1-distill-llama-8b qwen25-7b-distilled siglip2-so400m '
             'whisper-large-v3-turbo phi4-14b deepseek-moe-16b qwen3-30b-a3b'.split())
VARIANT = 'bank-physical-v8-gate3'
RESEARCH_SHA = '8746d3b08f99bd201741fafa447185121b73772e413bb080dbadad84c8a9e789'
BASE = Path('/data/mbravo/table3-final-20261002')
ROOT = Path(os.environ.get('NZIP_RUN_ROOT', '/data/mbravo/table3-refresh-20261006'))
INPUTS = Path(os.environ.get('NZIP_INPUTS', '/dev/shm/mbravo-table3-refresh-20261006/inputs'))
LARGE_KEYS = ('phi4-14b', 'deepseek-moe-16b', 'qwen3-30b-a3b')
GPU_HOSTS = {key: 'gx02' if key in LARGE_KEYS else 'multi_vm' for key in KEYS}
CAPACITY = {'multi_vm': 18 * (1 << 30), 'gx02': 100 * (1 << 30)}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def check_statistics(row, repetitions):
    import statistics
    assert len(row['samples']) == repetitions
    for metric in row['samples'][0]:
        values = [s[metric] for s in row['samples']]
        q1, _, q3 = statistics.quantiles(values, n=4, method='inclusive')
        assert row[metric] == dict(median=statistics.median(values), q1=q1, q3=q3,
                                  minimum=min(values), maximum=max(values))
    assert row['roundtrip_bitwise'] and row['input_unchanged']
    sizes = row['sizes']
    assert row['input']['raw_bytes'] == sizes['raw_bytes']
    assert row['exponent_ratio_pct'] == 100 * sizes['exponent_compressed_bytes'] / sizes['exponent_raw_bytes']
    assert row['full_ratio_pct'] == 100 * sizes['compressed_bytes'] / sizes['raw_bytes']


def self_test():
    import statistics
    values = list(range(1, 10))
    q1, _, q3 = statistics.quantiles(values, n=4, method='inclusive')
    row = dict(samples=[dict(seconds=v) for v in values],
               seconds=dict(median=5, q1=q1, q3=q3, minimum=1, maximum=9),
               roundtrip_bitwise=True, input_unchanged=True, input=dict(raw_bytes=200),
               sizes=dict(raw_bytes=200, compressed_bytes=150, exponent_raw_bytes=100,
                          exponent_compressed_bytes=50), exponent_ratio_pct=50, full_ratio_pct=75)
    check_statistics(row, 9)
    row['seconds']['median'] = 0
    try:
        check_statistics(row, 9)
    except AssertionError:
        pass
    else:
        raise AssertionError('Invalid median accepted')
    assert len(KEYS) == len(set(KEYS)) == 18
    assert sum(host == 'gx02' for host in GPU_HOSTS.values()) == 3
    print('18-model scope and summary checks passed')


def run():
    import torch
    from safetensors import safe_open
    from huggingface_hub import try_to_load_from_cache
    import research_v7 as r
    from neuralzip.setup import NeuralZipSetup
    from neuralzip.compressor import NeuralZipCompressor

    ROOT.mkdir(parents=True, exist_ok=True)
    INPUTS.mkdir(parents=True, exist_ok=True)
    lock = (ROOT / 'timing.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert sha(r.__file__) == RESEARCH_SHA
    assert r.ROOT == ROOT and r.INPUTS == INPUTS
    r.verify_runtime()
    assert r.bench.REPETITIONS == 9 and r.bench.WARMUPS == 4
    catalogue = read(BASE / 'manifest.json')
    donors = {k: catalogue['donors'][k] for k in KEYS}
    donors.update({'resnet101': 'resnet152', 'convnext-base': 'convnext-large',
                   'efficientnet-b3': 'efficientnet-b7'})
    preserved = {str(p): sha(p) for folder in ('table3', 'sources', 'donors', 'controls')
                 for p in sorted((BASE / folder).glob('*.json'))}
    protocol = dict(models=list(KEYS), donors=donors, cpu_host='godel', threads=12,
                    affinity=list(range(12)), warmups=4, repetitions=9,
                    reused_compatible_own_and_zipnn=True, setup_measured_separately_once=True,
                    source_only_bank=True, target_codebook_fit=False, gate_bits=3.0,
                    variant=VARIANT, research_sha256=RESEARCH_SHA,
                    benchmark_sha256=sha(r.bench.__file__), driver_sha256=sha(__file__),
                    immutable_runtime_files=read(BASE / 'source-manifest.json')['cpu_files'],
                    original_json_sha256=preserved, no_dfloat=True,
                    no_checkpoints_six_suite_or_commented_models=True,
                    gpu_hosts=GPU_HOSTS, capacity_bytes_by_host=CAPACITY,
                    single_gpu_only=True, no_cpu_offload=True)
    p = ROOT / 'protocol.json'
    if p.exists():
        assert read(p) == protocol, 'Capture a new runner version before resuming'
    else:
        r.save(p, protocol)

    def original(key):
        for folder in ('table3', 'donors', 'controls'):
            p = BASE / folder / f'{key}-input.json'
            if p.exists():
                return p, read(p)
        raise AssertionError('Missing original input identity: ' + key)

    def prepare(key):
        origin, info = original(key)
        destination = INPUTS / f'{key}.pt'
        if not destination.exists():
            spec = info['source']
            named = {}
            for filename, digest in spec['files'].items():
                if spec['kind'] == 'torchvision':
                    path = BASE / 'torch-cache/checkpoints' / filename
                else:
                    relative = (spec.get('subfolder', '') + '/' + filename).lstrip('/')
                    cached = try_to_load_from_cache(spec['id'], relative, revision=spec['revision'],
                                                    cache_dir=BASE / 'hf-cache')
                    assert isinstance(cached, str), 'Pinned weight is not cached: ' + key + '/' + filename
                    path = Path(cached)
                assert sha(path) == digest, 'Cached original file changed: ' + key + '/' + filename
                if filename.endswith('.json'):
                    continue
                if spec['kind'] == 'torchvision':
                    state = torch.load(path, map_location='cpu', weights_only=True)
                    for name, t in state.items():
                        if t.is_floating_point() and t.numel():
                            named[name] = t.to(torch.bfloat16).contiguous()
                    del state
                else:
                    assert filename.endswith('.safetensors'), filename
                    with safe_open(path, framework='pt', device='cpu') as shard:
                        for name in shard.keys():
                            t = shard.get_tensor(name)
                            if t.is_floating_point() and t.numel() and not (
                                    key.startswith('gpt2') and name.endswith(('.attn.bias', '.attn.masked_bias'))):
                                assert name not in named
                                named[name] = t.to(torch.bfloat16).contiguous()
                gc.collect()
            named = tuple(sorted(named.items()))
            records = r.tensor_manifest(named)
            assert hashlib.sha256(json.dumps(records, sort_keys=True).encode()).hexdigest() == info['bf16_manifest_sha256']
            assert len(named) == info['tensors'] and sum(t.numel() * 2 for _, t in named) == info['raw_bytes']
            temporary = destination.with_suffix('.pt.tmp')
            torch.save(dict(named), temporary)
            temporary.replace(destination)
            del named
        named = tuple(sorted(torch.load(destination, weights_only=True).items()))
        records = r.tensor_manifest(named)
        assert hashlib.sha256(json.dumps(records, sort_keys=True).encode()).hexdigest() == info['bf16_manifest_sha256']
        for suffix, value in (('input', info), ('tensors', records)):
            p = ROOT / f'{key}-{suffix}.json'
            if p.exists():
                assert read(p) == value
            else:
                r.save(p, value)
        return named

    def source_variant(source, variant):
        assert variant == VARIANT
        destination = ROOT / 'sources' / f'{source}-{variant}.setup.pkl'
        destination.parent.mkdir(exist_ok=True)
        if destination.exists():
            assert sha(destination) == read(destination.with_suffix('.json'))['setup_sha256']
            return destination
        # Reuse compatible CNN banks; their metadata records the original source construction.
        for folder in ('transfer-family-ladder-20261005-1320', 'transfer-convnext-ladder-20261005-1352'):
            parent = BASE.parent / folder / 'sources' / destination.name
            if parent.exists():
                meta = read(parent.with_suffix('.json'))
                assert sha(parent) == meta['setup_sha256']
                _, info = original(source)
                assert meta['source'] == info
                shutil.copy2(parent, destination)
                shutil.copy2(parent.with_suffix('.json'), destination.with_suffix('.json'))
                return destination
        parent = r.source_bank(source, 'bank-physical-v7')
        meta = read(parent.with_suffix('.json'))
        setup = NeuralZipSetup.load(parent)
        assert setup.bank_trigger_bits == 4.0 and not setup.chunk_codebooks
        before = setup.codebooks, dict(setup.tensor_codebooks), dict(setup.global_codebooks)
        setup.bank_trigger_bits = 3.0
        assert before == (setup.codebooks, setup.tensor_codebooks, setup.global_codebooks)
        setup.save(destination)
        meta.update(variant=VARIANT, setup_sha256=sha(destination),
                    parent_v7_setup_sha256=sha(parent), reuse_gate_bits=3.0,
                    only_changed_setup_field='bank_trigger_bits', no_source_retraining=True,
                    codebooks_and_maps_byte_identical_to_v7=True, gate_driver_sha256=sha(__file__))
        r.save(destination.with_suffix('.json'), meta)
        if source not in KEYS:
            (INPUTS / f'{source}.pt').unlink(missing_ok=True)
        return destination

    r.prepare, r.source_key, r.source_variant = prepare, donors.__getitem__, source_variant

    def plan_rows(codec):
        books = {b.codebook_id: hashlib.sha256(b.codebook + b.vocab).hexdigest() for b in codec.export_codebooks()}
        return [(k, [(m['kind'], books.get(m.get('codebook_id'))) for m in modes])
                for k, modes in sorted(codec._transfer_chunk_modes.items())]

    def packet(key, row):
        out = ROOT / 'gpu-ready' / key
        out.mkdir(parents=True, exist_ok=True)
        if (out / 'READY.json').exists():
            assert all(sha(out / name) == digest for name, digest in read(out / 'READY.json').items())
            return
        info = read(ROOT / f'{key}-input.json')
        for name in (f'{key}-input.json', f'{key}-tensors.json', f'{key}-new.json',
                     f'{key}-zipnn.json', f'{key}-{VARIANT}.json'):
            shutil.copy2(ROOT / name, out / name)
        proof = dict(model=key, donor=donors[key], spec=catalogue['models'][key],
                     variant=VARIANT, source_bank_sha256=row['source_setup_sha256'],
                     bf16_manifest_sha256=info['bf16_manifest_sha256'],
                     raw_bytes=info['raw_bytes'], gpu_host=GPU_HOSTS[key],
                     capacity_bytes=CAPACITY[GPU_HOSTS[key]],
                     capacity_excluded=info['raw_bytes'] > CAPACITY[GPU_HOSTS[key]],
                     target_codebook_fit=False, codebooks_byte_identical_to_source=True,
                     cpu_record_sha256=sha(ROOT / f'{key}-{VARIANT}.json'))
        if not proof['capacity_excluded']:
            named = prepare(key)
            setup = NeuralZipSetup.load(row['transferred_setup_path'])
            assert not setup.chunk_codebooks
            codec = r.BankCompressor(setup, threads=12)
            codec._add_global_codebooks()
            codec.prepare_storage_transfer_target(named)
            selected = plan_rows(codec)
            portable = copy.deepcopy(setup)
            portable.chunk_codebooks, portable.tensor_codebooks = {}, {}
            for name, tensor in named:
                for stream in (0, 1):
                    k = codec._transfer_plan_key(name, tensor, stream)
                    ids = tuple(m.get('codebook_id') for m in codec._transfer_chunk_modes[k])
                    portable.tensor_codebooks[k] = ids[0]
                    portable.chunk_codebooks[(*k, tensor.numel())] = ids
            frozen = out / f'{key}-foreign.setup.pkl'
            portable.save(frozen)
            assert portable.codebooks == setup.codebooks
            verifier = NeuralZipCompressor(portable, threads=12)
            verifier._add_global_codebooks()
            verifier.prepare_storage_transfer_target(named)
            assert plan_rows(verifier) == selected
            shutil.copy2(BASE / 'table3' / f'{key}-new.setup.pkl', out / f'{key}-new.setup.pkl')
            proof.update(input_file=str(INPUTS / f'{key}.pt'), input_file_sha256=sha(INPUTS / f'{key}.pt'),
                         frozen_setup_sha256=sha(frozen), frozen_plan=selected,
                         frozen_plan_sha256=hashlib.sha256(json.dumps(selected, sort_keys=True).encode()).hexdigest(),
                         own_setup_sha256=sha(out / f'{key}-new.setup.pkl'),
                         target_routing_only_no_fitting=True)
        r.save(out / 'proof.json', proof)
        r.save(out / 'READY.json', {p.name: sha(p) for p in sorted(out.iterdir()) if p.is_file()})

    completed, failures = [], []
    for key in KEYS:
        if (ROOT / f'{key}-CPU-COMPLETE.json').exists():
            packet(key, read(ROOT / f'{key}-{VARIANT}.json'))
            completed.append(key)
            continue
        phase = 'input'
        try:
            r.save(ROOT / 'progress.json', dict(finished=False, model=key, phase=phase,
                                               completed=completed, errors=failures))
            prepare(key)
            phase = 'compatible-record-validation'
            for method in ('new', 'zipnn'):
                old = BASE / 'table3' / f'{key}-{method}.json'
                row = read(old)
                check_statistics(row, 9)
                assert row['input'] == read(ROOT / f'{key}-input.json')
                assert row['threads'] == 12 and row['affinity'] == list(range(12))
                assert row['setup_source_sha256'] == sha(BASE / 'software/cpu/neuralzip/setup.py')
                if method == 'new':
                    assert row['compressor_source_sha256'] == sha(BASE / 'software/cpu/neuralzip/compressor.py')
                    assert row['encode_never_fits'] and len(row['setup_samples']) == 1
                    assert row['setup_seconds']['median'] == row['setup_samples'][0]
                destination = ROOT / old.name
                if destination.exists():
                    assert sha(destination) == sha(old)
                else:
                    shutil.copy2(old, destination)
            phase = 'foreign-compression'
            r.save(ROOT / 'progress.json', dict(finished=False, model=key, phase=phase,
                                               completed=completed, errors=failures))
            r.evaluate(key, VARIANT)
            row = read(ROOT / f'{key}-{VARIANT}.json')
            check_statistics(row, 9)
            assert row['setup_samples'] == [] and row['chunk_assignment_tensors'] == 0
            assert all(row[f] for f in ('roundtrip_bitwise', 'input_unchanged', 'encode_never_fits', 'source_only'))
            assert row['target_codebook_fit'] is False and row['target_routing_charged_in_encode']
            assert row['source_setup_sha256'] == sha(source_variant(donors[key], VARIANT))
            phase = 'gpu-packet'
            packet(key, row)
            r.save(ROOT / f'{key}-CPU-COMPLETE.json', dict(complete=True, model=key,
                        protocol_sha256=sha(ROOT / 'protocol.json'), ready_sha256=sha(ROOT / 'gpu-ready' / key / 'READY.json')))
            completed.append(key)
            if row['input']['raw_bytes'] > CAPACITY[GPU_HOSTS[key]]:
                (INPUTS / f'{key}.pt').unlink(missing_ok=True)
        except Exception as error:
            failure = dict(model=key, phase=phase, exception_type=type(error).__name__,
                           message=str(error) if isinstance(error, AssertionError) else 'See preserved run log')
            failures.append(failure)
            r.save(ROOT / f'{key}-failure-{len(failures)}.json', failure)
            print(json.dumps(failure), flush=True)
        gc.collect()
    assert all(sha(p) == digest for p, digest in preserved.items()), 'Original metadata changed'
    r.save(ROOT / 'progress.json', dict(finished=True, completed=completed, errors=failures))
    if len(completed) == 18 and not failures:
        r.save(ROOT / 'CPU-COMPLETE.json', dict(complete=True, models=18, protocol_sha256=sha(ROOT / 'protocol.json')))
    return bool(failures)


if __name__ == '__main__':
    if '--self-test' in sys.argv:
        self_test()
    else:
        raise SystemExit(run())
